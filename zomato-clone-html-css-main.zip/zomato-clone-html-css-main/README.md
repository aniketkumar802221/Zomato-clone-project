# Zomato Clone

This is the clone of a popular food ordering website [Zomato](https://www.zomato.com/).

Typography:
Zomato uses the font "Okra" which is not available to the public, so we're gonna use a similar font, [Open Sans](https://fonts.google.com/specimen/Open+Sans)
